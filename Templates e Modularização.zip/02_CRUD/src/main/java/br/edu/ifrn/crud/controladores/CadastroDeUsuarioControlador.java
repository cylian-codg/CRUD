package br.edu.ifrn.crud.controladores;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.crud.dominio.Profissao;
import br.edu.ifrn.crud.dominio.Usuario;
import br.edu.ifrn.crud.dto.AutocompleteDTO;
import br.edu.ifrn.crud.repository.UsuarioRepository;

@Controller
@RequestMapping("/usuarios")
public class CadastroDeUsuarioControlador {
	
	@Autowired
	private UsuarioRepository usuarioRepository;
	
	@Autowired
	private ProfissaoRepository profissaoRepository; 

	@GetMapping("/cadastro")
	public String entrarCadastro(ModelMap model) {
		model.addAttribute("usuario", new Usuario());
		return "usuario/cadastro";
	}
	private List<String> validarDados(Usuario usuario){
		List<String> msgs = new ArrayList<>();
		if (usuario.getNome() == null || usuario.getNome().isEmpty()) {
			msgs.add("o campo nome é obrigatório.");
		}
			if (usuario.getEmail() == null || usuario.getEmail().isEmpty()) {
				msgs.add("O campo email é obrigatório.");
			}
			if (usuario.getProfissao() == null || usuario.getProfissao().getId() == 0) {
					msgs.add("O campo profissão é obrigatório.");
				}
					if (usuario.getSenha() == null || usuario.getSenha().isEmpty()) {
						msgs.add("O campo senha é obrigatório.");
					}
						if (usuario.getSexo() == null || usuario.getSexo().isEmpty()) {
							msgs.add("O campo sexo é obrigatório.");
		}
						return msgs;
	}
	
	
	@PostMapping("/salvar")
	public String salvar (Usuario usuario, RedirectAttributes attr,  
			ModelMap model, HttpSession sessao) {
		
		usuarioRepository.save(usuario);
		attr.addFlashAttribute("msgSucesso", "operação realizada com sucesso!");		
			return"redirect:/usuarios/cadastro";
			
	}
	
	
	@GetMapping("/editar/{id}")
	public String iniciarEdicao(
			@PathVariable("id") Integer idUsuario,
			ModelMap model,
			HttpSession sessao
		) {
		
		Usuario u = usuarioRepository.findById(idUsuario).get();
		
		model.addAttribute("usuario", u);
		
		return"/usuario/cadastro";
		
	}
	
	@GetMapping("/autocompleteProfissoes")
	@Transactional(readOnly = true)
	@ResponseBody
	public  List<AutocompleteDTO> autocompleteProfissoes(
			@RequestParam("term") String termo){
		
		List<Profissao> profissoes = profissaoRepository.findByNome(termo);
		
		List<AutocompleteDTO> resultados = new ArrayList<>();
		
		profissoes.forEach(p -> resultados.add(
					new AutocompleteDTO(p.getNome(), p.getId())
				));
		
		return resultados;
	}
	
	
}
